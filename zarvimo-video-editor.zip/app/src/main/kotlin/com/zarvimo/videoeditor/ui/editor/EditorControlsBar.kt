package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallMerge
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary

/**
 * The editor's bottom quick-action strip: a horizontally scrollable row of
 * icon-over-label chips, in the spirit of Zarvimo's branding reference, plus
 * a prominent gradient Export button below it (its "Download Now" CTA).
 *
 * Only Trim & Cut and Delete are backed by real Phase 1 functionality and
 * need a selected clip. Merge Videos, Add Music, Apply Filters, Slow Motion
 * and Reverse Video are not implemented yet — shown dimmed, routing to
 * [onComingSoon] on tap rather than silently doing nothing.
 */
@Composable
fun EditorControlsBar(
    hasSelectedClip: Boolean,
    onSplit: () -> Unit,
    onDeleteClip: () -> Unit,
    onExport: () -> Unit,
    onComingSoon: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val mergeLabel = stringResource(id = R.string.quickaction_merge_videos)
    val musicLabel = stringResource(id = R.string.quickaction_add_music)
    val filtersLabel = stringResource(id = R.string.quickaction_apply_filters)
    val slowMotionLabel = stringResource(id = R.string.quickaction_slow_motion)
    val reverseLabel = stringResource(id = R.string.quickaction_reverse_video)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            QuickActionChip(
                icon = Icons.Filled.ContentCut,
                label = stringResource(id = R.string.quickaction_trim_cut),
                enabled = hasSelectedClip,
                onClick = onSplit
            )
            QuickActionChip(
                icon = Icons.Filled.Delete,
                label = stringResource(id = R.string.quickaction_delete),
                enabled = hasSelectedClip,
                onClick = onDeleteClip,
                tint = ZarvimoMagenta
            )
            QuickActionChip(
                icon = Icons.Filled.CallMerge,
                label = mergeLabel,
                enabled = false,
                onClick = { onComingSoon(mergeLabel) }
            )
            QuickActionChip(
                icon = Icons.Filled.LibraryMusic,
                label = musicLabel,
                enabled = false,
                onClick = { onComingSoon(musicLabel) }
            )
            QuickActionChip(
                icon = Icons.Filled.FilterVintage,
                label = filtersLabel,
                enabled = false,
                onClick = { onComingSoon(filtersLabel) }
            )
            QuickActionChip(
                icon = Icons.Filled.SlowMotionVideo,
                label = slowMotionLabel,
                enabled = false,
                onClick = { onComingSoon(slowMotionLabel) }
            )
            QuickActionChip(
                icon = Icons.Filled.FastRewind,
                label = reverseLabel,
                enabled = false,
                onClick = { onComingSoon(reverseLabel) }
            )
        }

        NeonGradientButton(
            text = stringResource(id = R.string.editor_export),
            onClick = onExport,
            icon = Icons.Filled.FileDownload,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun QuickActionChip(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    tint: Color = ZarvimoElectricBlue
) {
    val contentColor = if (enabled) ZarvimoTextPrimary else ZarvimoTextSecondary.copy(alpha = 0.5f)
    Column(
        modifier = Modifier
            .width(64.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (enabled) tint else contentColor
        )
        Text(
            text = label,
            color = contentColor,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
