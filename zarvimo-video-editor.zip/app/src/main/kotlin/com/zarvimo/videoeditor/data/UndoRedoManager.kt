package com.zarvimo.videoeditor.data

/**
 * Generic bounded undo/redo history over immutable snapshots of type [T].
 *
 * Usage: the editor calls [push] with the *new* state after every mutating
 * action (add/move/trim/split/delete clip, add/edit overlay, change volume…).
 * The previous state is recorded automatically. [undo]/[redo] move the
 * current-state pointer across that history and return the state that is now
 * current, so the caller can simply assign it back to its own state holder.
 */
class UndoRedoManager<T>(initial: T, private val maxHistory: Int = 50) {

    private val undoStack = ArrayDeque<T>()
    private val redoStack = ArrayDeque<T>()
    private var current: T = initial

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun current(): T = current

    /** Records [newState] as current, pushing the previous current state onto the undo stack. */
    fun push(newState: T) {
        if (newState == current) return
        undoStack.addLast(current)
        if (undoStack.size > maxHistory) undoStack.removeFirst()
        current = newState
        redoStack.clear()
    }

    fun undo(): T {
        val previous = undoStack.removeLastOrNull() ?: return current
        redoStack.addLast(current)
        current = previous
        return current
    }

    fun redo(): T {
        val next = redoStack.removeLastOrNull() ?: return current
        undoStack.addLast(current)
        current = next
        return current
    }

    /** Clears all history and sets a fresh current state, e.g. after loading a new project. */
    fun reset(newInitial: T) {
        undoStack.clear()
        redoStack.clear()
        current = newInitial
    }
}
