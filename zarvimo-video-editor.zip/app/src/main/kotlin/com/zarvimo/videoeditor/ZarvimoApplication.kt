package com.zarvimo.videoeditor

import android.app.Application

class ZarvimoApplication : Application()
