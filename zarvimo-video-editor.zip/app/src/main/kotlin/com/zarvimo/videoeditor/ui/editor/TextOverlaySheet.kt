package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.ui.components.NeonGradientButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoDanger
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoGold
import com.zarvimo.videoeditor.ui.theme.ZarvimoMagenta
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import com.zarvimo.videoeditor.ui.theme.ZarvimoViolet
import java.util.UUID

private val OVERLAY_COLOR_CHOICES = listOf(
    Color.White, ZarvimoElectricBlue, ZarvimoViolet, ZarvimoMagenta, ZarvimoGold
)

/**
 * Bottom sheet to add a new text overlay (anchored at [currentPlayheadUs]) or
 * edit/remove an existing one. Duration is authored as a simple 1–10s slider
 * from the start time rather than two separate time pickers, which is enough
 * precision for Phase 1 captions/titles.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TextOverlaySheet(
    existingOverlay: TextOverlay?,
    currentPlayheadUs: Long,
    onSave: (TextOverlay) -> Unit,
    onRemove: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var text by remember(existingOverlay) { mutableStateOf(existingOverlay?.text ?: "") }
    var color by remember(existingOverlay) {
        mutableStateOf(existingOverlay?.colorArgb?.let { Color(it) } ?: Color.White)
    }
    val startUs = existingOverlay?.startTimeUs ?: currentPlayheadUs
    var durationSeconds by remember(existingOverlay) {
        mutableFloatStateOf(
            existingOverlay
                ?.let { (it.endTimeUs - it.startTimeUs) / 1_000_000f }
                ?.coerceIn(1f, 10f)
                ?: 3f
        )
    }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth().padding(24.dp)) {
            Text(
                text = stringResource(id = R.string.text_overlay_title),
                style = MaterialTheme.typography.titleMedium
            )

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(stringResource(id = R.string.text_overlay_hint)) },
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
            )

            Text(
                text = stringResource(id = R.string.text_overlay_color),
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OVERLAY_COLOR_CHOICES.forEach { swatch ->
                    Row(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(swatch)
                            .border(
                                width = if (swatch == color) 3.dp else 1.dp,
                                color = if (swatch == color) ZarvimoElectricBlue else ZarvimoTextSecondary,
                                shape = CircleShape
                            )
                            .clickable { color = swatch }
                    ) {}
                }
            }

            Text(
                text = "Duration: ${durationSeconds.toInt()}s",
                style = MaterialTheme.typography.bodyMedium,
                color = ZarvimoTextSecondary,
                modifier = Modifier.padding(top = 16.dp)
            )
            Slider(
                value = durationSeconds,
                onValueChange = { durationSeconds = it },
                valueRange = 1f..10f,
                steps = 8
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                if (onRemove != null) {
                    TextButton(onClick = { onRemove(); onDismiss() }) {
                        Text(
                            text = stringResource(id = R.string.text_overlay_remove),
                            color = ZarvimoDanger
                        )
                    }
                }
            }

            NeonGradientButton(
                text = stringResource(
                    id = if (existingOverlay == null) R.string.text_overlay_add else R.string.text_overlay_update
                ),
                enabled = text.isNotBlank(),
                onClick = {
                    val endUs = startUs + (durationSeconds * 1_000_000L).toLong()
                    onSave(
                        TextOverlay(
                            id = existingOverlay?.id ?: UUID.randomUUID().toString(),
                            text = text,
                            colorArgb = color.toArgb(),
                            startTimeUs = startUs,
                            endTimeUs = endUs,
                            xFraction = existingOverlay?.xFraction ?: 0.5f,
                            yFraction = existingOverlay?.yFraction ?: 0.85f,
                            fontSizeSp = existingOverlay?.fontSizeSp ?: 28f
                        )
                    )
                    onDismiss()
                },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
            )
        }
    }
}
