package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEmotions
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoSurface
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextPrimary
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary

/**
 * The editor's left-hand vertical tool rail (Media/Audio/Text/Effects/Stickers/
 * Overlay/Adjust), in the spirit of Zarvimo's branding reference.
 *
 * Only [sidebar_media], [sidebar_text] and [sidebar_adjust] are backed by real
 * Phase 1 functionality — Audio mixing, Effects, Stickers and an Overlay
 * layer stack are not implemented yet, so those three items are shown dimmed
 * and route to [onComingSoon] instead of pretending to do something. This is
 * a deliberate "not yet" state, not a disabled dead button: tapping them
 * still responds, just with that message, so nothing on screen looks broken.
 */
@Composable
fun EditorSidebarRail(
    adjustEnabled: Boolean,
    onMediaClick: () -> Unit,
    onTextClick: () -> Unit,
    onAdjustClick: () -> Unit,
    onComingSoon: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val audioLabel = stringResource(id = R.string.sidebar_audio)
    val effectsLabel = stringResource(id = R.string.sidebar_effects)
    val stickersLabel = stringResource(id = R.string.sidebar_stickers)
    val overlayLabel = stringResource(id = R.string.sidebar_overlay)

    Column(
        modifier = modifier
            .fillMaxHeight()
            .width(76.dp)
            .background(ZarvimoSurface)
            .verticalScroll(rememberScrollState())
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        SidebarRailItem(
            icon = Icons.Filled.VideoLibrary,
            label = stringResource(id = R.string.sidebar_media),
            enabled = true,
            onClick = onMediaClick
        )
        SidebarRailItem(
            icon = Icons.Filled.MusicNote,
            label = audioLabel,
            enabled = false,
            onClick = { onComingSoon(audioLabel) }
        )
        SidebarRailItem(
            icon = Icons.Filled.TextFields,
            label = stringResource(id = R.string.sidebar_text),
            enabled = true,
            onClick = onTextClick
        )
        SidebarRailItem(
            icon = Icons.Filled.AutoAwesome,
            label = effectsLabel,
            enabled = false,
            onClick = { onComingSoon(effectsLabel) }
        )
        SidebarRailItem(
            icon = Icons.Filled.EmojiEmotions,
            label = stickersLabel,
            enabled = false,
            onClick = { onComingSoon(stickersLabel) }
        )
        SidebarRailItem(
            icon = Icons.Filled.Layers,
            label = overlayLabel,
            enabled = false,
            onClick = { onComingSoon(overlayLabel) }
        )
        SidebarRailItem(
            icon = Icons.Filled.Tune,
            label = stringResource(id = R.string.sidebar_adjust),
            enabled = adjustEnabled,
            onClick = onAdjustClick
        )
    }
}

@Composable
private fun SidebarRailItem(
    icon: ImageVector,
    label: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    val contentColor = if (enabled) ZarvimoTextPrimary else ZarvimoTextSecondary.copy(alpha = 0.5f)
    Column(
        modifier = Modifier
            .width(68.dp)
            .padding(vertical = 2.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (enabled) ZarvimoElectricBlue else contentColor,
            modifier = Modifier
        )
        Text(
            text = label,
            color = contentColor,
            style = MaterialTheme.typography.labelSmall,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
