package com.zarvimo.videoeditor.data.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * A single Zarvimo project: an ordered sequence of trimmed video clips, a set
 * of timed text overlays, and export preferences. This is the full state that
 * gets persisted to disk (see ProjectRepository) and that UndoRedoManager
 * snapshots on every edit.
 */
@Serializable
data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val clips: List<VideoClip> = emptyList(),
    val textOverlays: List<TextOverlay> = emptyList(),
    val aspectRatio: AspectRatio = AspectRatio.RATIO_16_9,
    val exportQuality: ExportQuality = ExportQuality.HD_1080,
    val thumbnailUri: String? = null
) {
    /** Total timeline duration in microseconds: the sum of every clip's trimmed length. */
    val totalDurationUs: Long
        get() = clips.sumOf { it.trimmedDurationUs }

    /** Clips in timeline order, regardless of how [clips] happens to be stored. */
    val orderedClips: List<VideoClip>
        get() = clips.sortedBy { it.order }

    companion object {
        fun newEmpty(name: String): Project = Project(name = name)
    }
}

/**
 * One source video trimmed to an in/out range and placed at [order] in the timeline.
 * Durations and trim points are stored in microseconds to match Media3's
 * [androidx.media3.common.MediaItem.ClippingConfiguration] units directly, so the
 * playback and export layers can use these values with no conversion.
 */
@Serializable
data class VideoClip(
    val id: String = UUID.randomUUID().toString(),
    val sourceUri: String,
    val sourceDurationUs: Long,
    val trimStartUs: Long = 0L,
    val trimEndUs: Long = sourceDurationUs,
    val volume: Float = 1f,
    val order: Int,
    val thumbnailUri: String? = null,
    val displayName: String = "Clip"
) {
    val trimmedDurationUs: Long
        get() = (trimEndUs - trimStartUs).coerceAtLeast(0L)

    /** Returns a copy trimmed to a new [newStartUs]..[newEndUs] range, clamped to the source. */
    fun withTrim(newStartUs: Long, newEndUs: Long): VideoClip {
        val clampedStart = newStartUs.coerceIn(0L, sourceDurationUs)
        val clampedEnd = newEndUs.coerceIn(clampedStart, sourceDurationUs)
        return copy(trimStartUs = clampedStart, trimEndUs = clampedEnd)
    }
}

/**
 * A timed text overlay, burned into the export and previewed live over the player.
 * Position is stored as fractions of the frame (0f..1f) so it survives changes
 * to [AspectRatio] or export resolution without re-authoring.
 */
@Serializable
data class TextOverlay(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val colorArgb: Int,
    val startTimeUs: Long,
    val endTimeUs: Long,
    val xFraction: Float = 0.5f,
    val yFraction: Float = 0.85f,
    val fontSizeSp: Float = 28f
) {
    fun isVisibleAt(positionUs: Long): Boolean = positionUs in startTimeUs until endTimeUs
}

@Serializable
enum class AspectRatio(val widthRatio: Int, val heightRatio: Int, val label: String) {
    RATIO_16_9(16, 9, "16:9"),
    RATIO_9_16(9, 16, "9:16"),
    RATIO_1_1(1, 1, "1:1"),
    RATIO_4_3(4, 3, "4:3");

    val ratio: Float get() = widthRatio.toFloat() / heightRatio.toFloat()
}

@Serializable
enum class ExportQuality(val targetHeight: Int, val videoBitrate: Int, val label: String) {
    SD_720(720, 6_000_000, "720p"),
    HD_1080(1080, 12_000_000, "1080p"),
    UHD_4K(2160, 40_000_000, "4K")
}
