package com.zarvimo.videoeditor.ui.dashboard

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zarvimo.videoeditor.data.ProjectRepository
import com.zarvimo.videoeditor.data.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DashboardUiState(
    val projects: List<Project> = emptyList(),
    val isLoading: Boolean = true
)

class DashboardViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ProjectRepository(application)

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            val projects = repository.listAll()
            _uiState.value = DashboardUiState(projects = projects, isLoading = false)
        }
    }

    fun createProject(name: String, onCreated: (Project) -> Unit) {
        viewModelScope.launch {
            val project = Project.newEmpty(name.ifBlank { "Untitled Project" })
            repository.save(project)
            refresh()
            onCreated(project)
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            repository.delete(projectId)
            refresh()
        }
    }
}
