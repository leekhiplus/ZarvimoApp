package com.zarvimo.videoeditor.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import com.zarvimo.videoeditor.data.model.TextOverlay

/**
 * Rasterizes one [TextOverlay] onto a transparent, frame-sized bitmap so it
 * can be composited back into the video via Media3's overlay effect. Baking
 * the exact on-screen position into the bitmap itself (rather than relying on
 * an overlay-positioning API) keeps the export path's dependency on Media3's
 * newer effects surface as small as possible.
 */
object TextOverlayRenderer {

    fun render(overlay: TextOverlay, widthPx: Int, heightPx: Int): Bitmap {
        val bitmap = Bitmap.createBitmap(
            widthPx.coerceAtLeast(1),
            heightPx.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = overlay.colorArgb
            // Scale the authored font size relative to a 720px-tall reference frame,
            // so overlays look the same proportion of the frame at any export quality.
            textSize = overlay.fontSizeSp * (heightPx / 720f)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
            setShadowLayer(8f, 0f, 2f, 0x99000000.toInt())
        }
        val x = (overlay.xFraction.coerceIn(0f, 1f)) * widthPx
        val y = (overlay.yFraction.coerceIn(0f, 1f)) * heightPx
        canvas.drawText(overlay.text, x, y, paint)
        return bitmap
    }
}
