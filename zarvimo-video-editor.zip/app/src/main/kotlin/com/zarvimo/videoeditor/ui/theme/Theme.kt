package com.zarvimo.videoeditor.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/**
 * Zarvimo is a dark-first, neon-on-navy app by design: the color scheme is
 * intentionally the same regardless of the system's light/dark setting.
 */
private val ZarvimoColorScheme = darkColorScheme(
    primary = ZarvimoElectricBlue,
    onPrimary = Color.Black,
    secondary = ZarvimoViolet,
    onSecondary = Color.White,
    tertiary = ZarvimoMagenta,
    onTertiary = Color.White,
    background = ZarvimoBackground,
    onBackground = ZarvimoTextPrimary,
    surface = ZarvimoSurface,
    onSurface = ZarvimoTextPrimary,
    surfaceVariant = ZarvimoSurfaceVariant,
    onSurfaceVariant = ZarvimoTextSecondary,
    error = ZarvimoDanger,
    onError = Color.White,
    outline = ZarvimoSurfaceElevated
)

@Composable
fun ZarvimoTheme(
    // Accepted for API completeness / future light-theme support; Phase 1 always
    // renders the neon-on-navy scheme regardless of the system setting.
    useSystemTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ZarvimoColorScheme,
        typography = ZarvimoTypography,
        content = content
    )
}
