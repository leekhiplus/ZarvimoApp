package com.zarvimo.videoeditor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.zarvimo.videoeditor.navigation.ZarvimoNavGraph
import com.zarvimo.videoeditor.ui.theme.ZarvimoBackground
import com.zarvimo.videoeditor.ui.theme.ZarvimoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZarvimoTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = ZarvimoBackground
                ) {
                    ZarvimoNavGraph()
                }
            }
        }
    }
}
