package com.zarvimo.videoeditor.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.ui.components.NeonIconButton
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.util.TimeFormat

/**
 * The video surface: a Media3 [PlayerView] (no built-in transport controls — Zarvimo
 * draws its own prev/play/next row over the bottom of the frame, plus a
 * current/total timestamp) with a Compose layer on top that renders whichever
 * [TextOverlay]s are active at [positionUs], at their authored normalized
 * position. This Compose layer is preview-only; the exported file gets its overlays
 * burned in separately by [com.zarvimo.videoeditor.export.VideoExporter].
 */
@OptIn(UnstableApi::class)
@Composable
fun PreviewPlayerView(
    player: ExoPlayer,
    overlays: List<TextOverlay>,
    positionUs: Long,
    modifier: Modifier = Modifier,
    totalDurationUs: Long? = null,
    isPlaying: Boolean = false,
    onPlayPause: (() -> Unit)? = null,
    onPreviousClip: (() -> Unit)? = null,
    onNextClip: (() -> Unit)? = null,
    onOverlayClick: (TextOverlay) -> Unit = {}
) {
    var frameSize by remember { mutableStateOf(IntSize.Zero) }

    Box(
        modifier = modifier
            .background(Color.Black)
            .onSizeChanged { frameSize = it }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    this.player = player
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
            update = { view -> view.player = player }
        )

        if (frameSize.width > 0 && frameSize.height > 0) {
            val density = LocalDensity.current
            overlays.filter { it.isVisibleAt(positionUs) }.forEach { overlay ->
                val xDp = with(density) { (overlay.xFraction * frameSize.width).toDp() }
                val yDp = with(density) { (overlay.yFraction * frameSize.height).toDp() }
                Text(
                    text = overlay.text,
                    color = Color(overlay.colorArgb),
                    fontSize = overlay.fontSizeSp.sp,
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(x = xDp, y = yDp)
                        .clickable { onOverlayClick(overlay) }
                )
            }
        }

        // Transport row: current/total timestamp + prev | play/pause | next, drawn
        // over the bottom of the frame — only when the caller wired up transport
        // callbacks, so this view still works standalone (e.g. a future thumbnail
        // preview) without forcing every caller to supply them.
        if (onPlayPause != null) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = TimeFormat.formatUs(positionUs),
                    color = Color.White,
                    fontSize = 12.sp
                )

                Spacer(Modifier.weight(1f))

                if (onPreviousClip != null) {
                    NeonIconButton(
                        icon = Icons.Filled.SkipPrevious,
                        contentDescription = stringResource(id = R.string.editor_previous_clip),
                        onClick = onPreviousClip,
                        size = 34.dp
                    )
                    Spacer(Modifier.width(10.dp))
                }

                NeonIconButton(
                    icon = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                    contentDescription = stringResource(
                        id = if (isPlaying) R.string.editor_pause else R.string.editor_play
                    ),
                    onClick = onPlayPause,
                    tint = ZarvimoElectricBlue,
                    size = 42.dp
                )

                if (onNextClip != null) {
                    Spacer(Modifier.width(10.dp))
                    NeonIconButton(
                        icon = Icons.Filled.SkipNext,
                        contentDescription = stringResource(id = R.string.editor_next_clip),
                        onClick = onNextClip,
                        size = 34.dp
                    )
                }

                Spacer(Modifier.weight(1f))

                Text(
                    text = TimeFormat.formatUs(totalDurationUs ?: 0L),
                    color = Color.White,
                    fontSize = 12.sp
                )
            }
        }
    }
}
