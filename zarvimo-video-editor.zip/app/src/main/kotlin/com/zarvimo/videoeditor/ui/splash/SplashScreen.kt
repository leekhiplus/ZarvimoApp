package com.zarvimo.videoeditor.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.ui.theme.ZarvimoBackground
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary
import kotlinx.coroutines.delay

/**
 * Animated brand splash: the Zarvimo "Z" scales/fades in, the wordmark follows,
 * then [onFinished] fires after [holdMillis] so the caller can navigate on.
 */
@Composable
fun SplashScreen(
    onFinished: () -> Unit,
    holdMillis: Long = 1400L
) {
    val logoScale = remember { Animatable(0.6f) }
    val logoAlpha = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        logoScale.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(Unit) {
        logoAlpha.animateTo(1f, tween(500, easing = LinearOutSlowInEasing))
    }
    LaunchedEffect(Unit) {
        delay(250)
        textAlpha.animateTo(1f, tween(450, easing = LinearOutSlowInEasing))
        delay(holdMillis)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ZarvimoBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_zarvimo_logo),
                contentDescription = stringResource(id = R.string.app_name),
                modifier = Modifier
                    .size(96.dp)
                    .scale(logoScale.value)
                    .alpha(logoAlpha.value)
            )
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.alpha(textAlpha.value)
            ) {
                Text(
                    text = "ZARVIMO",
                    style = MaterialTheme.typography.displaySmall,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = stringResource(id = R.string.app_tagline),
                    style = MaterialTheme.typography.bodyMedium,
                    color = ZarvimoTextSecondary,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}
