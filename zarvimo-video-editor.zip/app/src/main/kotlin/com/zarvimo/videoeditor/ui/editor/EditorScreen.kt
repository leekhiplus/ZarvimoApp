package com.zarvimo.videoeditor.ui.editor

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavBackStackEntry
import com.zarvimo.videoeditor.R
import com.zarvimo.videoeditor.navigation.PICKED_URIS_KEY
import com.zarvimo.videoeditor.export.ExportState
import com.zarvimo.videoeditor.ui.theme.ZarvimoElectricBlue
import com.zarvimo.videoeditor.ui.theme.ZarvimoTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    projectId: String,
    navBackStackEntry: NavBackStackEntry,
    onBack: () -> Unit,
    onOpenMediaPicker: () -> Unit,
    viewModel: EditorViewModel = viewModel()
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val positionUs by viewModel.playbackPositionUs.collectAsState()
    val exportState by viewModel.exporter.state.collectAsState()

    var showVolumeSheet by remember { mutableStateOf(false) }
    var showTextSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var editingOverlayId by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(projectId) { viewModel.loadProject(projectId) }

    // Receives the Uris picked in MediaPickerScreen via the standard Navigation-Compose
    // "previous back stack entry's SavedStateHandle" result pattern.
    val pickedUris by navBackStackEntry.savedStateHandle
        .getStateFlow(PICKED_URIS_KEY, emptyList<String>())
        .collectAsState()
    LaunchedEffect(pickedUris) {
        if (pickedUris.isNotEmpty()) {
            viewModel.addClips(pickedUris.map { Uri.parse(it) })
            navBackStackEntry.savedStateHandle[PICKED_URIS_KEY] = emptyList<String>()
        }
    }

    val project = uiState.project

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(project?.name ?: stringResource(id = R.string.app_name)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(id = R.string.action_back)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.save() }) {
                        Icon(
                            imageVector = Icons.Filled.Save,
                            contentDescription = stringResource(id = R.string.editor_save)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            when {
                uiState.isLoading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator(color = ZarvimoElectricBlue) }

                project == null -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { Text("Project not found", color = ZarvimoTextSecondary) }

                else -> Column(modifier = Modifier.fillMaxSize()) {
                    PreviewPlayerView(
                        player = viewModel.playerManager.player,
                        overlays = project.textOverlays,
                        positionUs = positionUs,
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(project.aspectRatio.ratio),
                        onOverlayClick = { overlay ->
                            editingOverlayId = overlay.id
                            showTextSheet = true
                        }
                    )

                    if (project.clips.isEmpty()) {
                        Box(
                            modifier = Modifier.fillMaxWidth().height(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = stringResource(id = R.string.editor_empty_timeline),
                                color = ZarvimoTextSecondary
                            )
                        }
                    } else {
                        TimelineView(
                            clips = project.clips,
                            selectedClipId = uiState.selectedClipId,
                            playheadUs = positionUs,
                            onSelectClip = viewModel::selectClip,
                            onSeekToClipStart = { clipId ->
                                val clip = project.orderedClips.firstOrNull { it.id == clipId }
                                val index = project.orderedClips.indexOfFirst { it.id == clipId }
                                if (clip != null && index >= 0) {
                                    val startUs = project.orderedClips.take(index).sumOf { it.trimmedDurationUs }
                                    viewModel.playerManager.seekToTimelineUs(startUs)
                                }
                            },
                            onReorder = viewModel::reorderClip,
                            onTrimChanged = viewModel::trimClip,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(84.dp)
                        )
                    }

                    EditorControlsBar(
                        isPlaying = isPlaying,
                        canUndo = uiState.canUndo,
                        canRedo = uiState.canRedo,
                        hasSelectedClip = uiState.selectedClipId != null,
                        onPlayPause = viewModel.playerManager::playPause,
                        onUndo = viewModel::undo,
                        onRedo = viewModel::redo,
                        onAddClip = onOpenMediaPicker,
                        onSplit = viewModel::splitAtPlayhead,
                        onDeleteClip = {
                            uiState.selectedClipId?.let(viewModel::deleteClip)
                        },
                        onVolume = { showVolumeSheet = true },
                        onAddText = {
                            editingOverlayId = null
                            showTextSheet = true
                        },
                        onExport = { showExportSheet = true }
                    )
                }
            }
        }
    }

    if (showVolumeSheet && project != null) {
        val selectedClip = project.clips.firstOrNull { it.id == uiState.selectedClipId }
        if (selectedClip != null) {
            VolumeControlSheet(
                initialVolume = selectedClip.volume,
                onVolumeChanged = { volume -> viewModel.setClipVolume(selectedClip.id, volume) },
                onDismiss = { showVolumeSheet = false }
            )
        } else {
            showVolumeSheet = false
        }
    }

    if (showTextSheet && project != null) {
        val existing = project.textOverlays.firstOrNull { it.id == editingOverlayId }
        TextOverlaySheet(
            existingOverlay = existing,
            currentPlayheadUs = positionUs,
            onSave = { overlay ->
                if (existing == null) viewModel.addTextOverlay(overlay) else viewModel.updateTextOverlay(overlay)
            },
            onRemove = existing?.let { { viewModel.removeTextOverlay(it.id) } },
            onDismiss = { showTextSheet = false }
        )
    }

    if (showExportSheet) {
        ExportSheet(
            state = exportState,
            onStart = { quality -> viewModel.exportProject(quality) },
            onCancel = { viewModel.cancelExport() },
            onShare = { file ->
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "video/mp4"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(Intent.createChooser(intent, "Share exported video"))
            },
            onDismiss = { showExportSheet = false }
        )
    }
}
