package com.zarvimo.videoeditor.util

import java.util.Locale
import kotlin.math.floor

/** Formatting and math helpers shared by the timeline, preview player and export UI. */
object TimeFormat {

    /** Formats a duration in microseconds as `H:MM:SS` (hours omitted when zero) or `M:SS`. */
    fun formatUs(durationUs: Long): String {
        val totalSeconds = floor(durationUs.coerceAtLeast(0L) / 1_000_000.0).toLong()
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, seconds)
        }
    }

    /** Formats a duration in microseconds as `M:SS.d` with one decimal place, for trim handles. */
    fun formatUsPrecise(durationUs: Long): String {
        val clamped = durationUs.coerceAtLeast(0L)
        val totalTenths = clamped / 100_000L
        val minutes = totalTenths / 600
        val seconds = (totalTenths / 10) % 60
        val tenths = totalTenths % 10
        return String.format(Locale.US, "%d:%02d.%d", minutes, seconds, tenths)
    }

    fun usToMs(us: Long): Long = us / 1000L
    fun msToUs(ms: Long): Long = ms * 1000L
}
