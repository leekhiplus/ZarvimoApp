package com.zarvimo.videoeditor

import com.zarvimo.videoeditor.data.model.Project
import com.zarvimo.videoeditor.data.model.TextOverlay
import com.zarvimo.videoeditor.data.model.VideoClip
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectModelsTest {

    @Test
    fun `totalDurationUs sums every clip's trimmed duration`() {
        val project = Project(
            name = "t",
            clips = listOf(
                VideoClip(sourceUri = "a", sourceDurationUs = 10_000_000, order = 0),
                VideoClip(
                    sourceUri = "b",
                    sourceDurationUs = 20_000_000,
                    trimStartUs = 2_000_000,
                    trimEndUs = 18_000_000,
                    order = 1
                )
            )
        )
        assertEquals(10_000_000L + 16_000_000L, project.totalDurationUs)
    }

    @Test
    fun `orderedClips sorts by order regardless of list insertion order`() {
        val clipB = VideoClip(id = "B", sourceUri = "b", sourceDurationUs = 1, order = 1)
        val clipA = VideoClip(id = "A", sourceUri = "a", sourceDurationUs = 1, order = 0)
        val project = Project(name = "t", clips = listOf(clipB, clipA))
        assertEquals(listOf("A", "B"), project.orderedClips.map { it.id })
    }

    @Test
    fun `withTrim clamps to source bounds`() {
        val clip = VideoClip(sourceUri = "x", sourceDurationUs = 10_000_000, order = 0)
        val trimmed = clip.withTrim(-5_000_000, 20_000_000)
        assertEquals(0L, trimmed.trimStartUs)
        assertEquals(10_000_000L, trimmed.trimEndUs)
    }

    @Test
    fun `withTrim never produces a negative-length clip`() {
        val clip = VideoClip(sourceUri = "x", sourceDurationUs = 10_000_000, order = 0)
        val trimmed = clip.withTrim(8_000_000, 2_000_000)
        assertTrue(trimmed.trimEndUs >= trimmed.trimStartUs)
    }

    @Test
    fun `trimmedDurationUs reflects the trim range`() {
        val clip = VideoClip(
            sourceUri = "x",
            sourceDurationUs = 10_000_000,
            trimStartUs = 1_000_000,
            trimEndUs = 4_000_000,
            order = 0
        )
        assertEquals(3_000_000L, clip.trimmedDurationUs)
    }

    @Test
    fun `isVisibleAt is true only within the overlay's time window`() {
        val overlay = TextOverlay(
            text = "hello",
            colorArgb = 0xFFFFFFFF.toInt(),
            startTimeUs = 1_000_000,
            endTimeUs = 3_000_000
        )
        assertFalse(overlay.isVisibleAt(500_000))
        assertTrue(overlay.isVisibleAt(1_000_000))
        assertTrue(overlay.isVisibleAt(2_999_999))
        assertFalse(overlay.isVisibleAt(3_000_000))
    }

    @Test
    fun `newEmpty creates a project with no clips or overlays`() {
        val project = Project.newEmpty("My Edit")
        assertEquals("My Edit", project.name)
        assertTrue(project.clips.isEmpty())
        assertTrue(project.textOverlays.isEmpty())
        assertEquals(0L, project.totalDurationUs)
    }
}
