# Zarvimo Video Editor — Phase 1

A real, working Android video editor built with Kotlin, Jetpack Compose, Gradle
Kotlin DSL, and AndroidX Media3. Premium black/navy UI with electric-blue,
violet and magenta neon accents.

> **Brand note:** this project was originally scaffolded as "Zafronix" and was
> renamed to **Zarvimo** at the user's request before this build — the
> application ID, package name (`com.zarvimo.videoeditor`), app name, launcher
> icon, splash screen and all in-app text use **Zarvimo** throughout.

## What's implemented in Phase 1

- **Splash screen** — animated Zarvimo "Z" logo + wordmark, then routes to the dashboard.
- **Dashboard** — list of saved projects (name, duration, last-edited date), create/delete, empty state.
- **Media picker** — browses on-device videos via `MediaStore` + the standard permission flow (`READ_MEDIA_VIDEO` on API 33+, `READ_EXTERNAL_STORAGE` below), multi-select grid with thumbnails and durations.
- **Editor workspace**
  - Live video preview (Media3 `ExoPlayer` + `PlayerView`) with play/pause and a playhead synced to the timeline.
  - Horizontally scrollable **timeline**: add clips, **reorder** (long-press + drag), **trim** (drag edge handles on the selected clip), **split** at the playhead, **delete** a clip.
  - Per-clip **volume** control (0–200%), previewed live and baked into the export.
  - **Text overlays**: add/edit/remove, positioned and timed, rendered live over the preview and burned into the exported file.
  - **Undo/redo** across every edit (add/trim/split/delete/reorder clips, volume, overlays).
  - **Local project save** — JSON on disk, no cloud dependency.
  - **Export** — renders a real H.264/AAC `.mp4` via Media3 `Transformer`, with a quality picker (720p/1080p/4K), live progress, cancel, and share-sheet on completion.
- **Architecture** — UI (Compose screens/components), timeline (`TimelineView` + gesture handling), project data (`data/model`, `ProjectRepository`, `UndoRedoManager`), playback (`PlayerManager`), and export (`VideoExporter`, `VolumeAudioProcessor`, `TextOverlayRenderer`) are separate, single-purpose modules under `app/src/main/kotlin/com/zarvimo/videoeditor/`, intended to be extended rather than rewritten in Phase 2.

### Known Phase 1 limitation

Text overlays are burned into the **exported** file for the full duration of
every clip they time-overlap, not frame-accurately clipped to their exact
start/end time within that clip (the live preview *does* show them at their
exact configured times, since that's just a Compose layer synced to the
player). This is called out in code at
`export/VideoExporter.kt::buildOverlayEffects`. Phase 2 replaces the
bitmap-overlay effect with a time-windowed shader to close this gap.

## Project structure

```
zarvimo-video-editor/
├── .github/workflows/android-build.yml   # CI: test + build debug APK on push/dispatch
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── kotlin/com/zarvimo/videoeditor/
│       │   │   ├── MainActivity.kt, ZarvimoApplication.kt
│       │   │   ├── data/            # models, ProjectRepository, UndoRedoManager
│       │   │   ├── playback/        # PlayerManager (ExoPlayer wrapper)
│       │   │   ├── export/          # VideoExporter (Media3 Transformer), volume & overlay effects
│       │   │   ├── navigation/      # ZarvimoNavGraph
│       │   │   ├── util/            # TimeFormat, MediaUtils
│       │   │   └── ui/              # theme, splash, dashboard, picker, editor, shared components
│       │   └── res/                 # colors, strings, themes, launcher icon, splash drawable
│       └── test/kotlin/com/zarvimo/videoeditor/   # unit tests
├── gradle/
│   ├── libs.versions.toml           # version catalog
│   └── wrapper/                     # gradle-wrapper.jar + .properties
├── gradlew / gradlew.bat
├── settings.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Building it — phone-friendly, no computer or terminal needed

You only need **one file**: `zarvimo-video-editor.zip`. There are two ways to
get it into a GitHub repo and building. Pick whichever is easier for you —
both end with the APK appearing under your repo's **Releases** tab.

### Option A — easiest on a phone, zero extraction

GitHub does not auto-extract an uploaded zip, but this repo's workflow does
it *for* you on GitHub's own servers, so you never touch a zip file yourself.

1. On github.com, create a **new repository**.
2. Tap **Add file → Create new file**. In the filename box, type the full
   path `.github/workflows/android-build.yml` (typing the slashes makes
   GitHub create those folders automatically). Paste in the workflow code
   below, then **Commit new file**.
3. Go back to the repo's main page → **Add file → Upload files** → choose
   `zarvimo-source.zip` from inside the zip you downloaded (see note below)
   → **Commit changes**.
4. Open the **Actions** tab → **Android Build** → **Run workflow**.
5. Wait for the green checkmark (first run takes ~10–15 minutes). Then open
   your repo's **Releases** (right sidebar on the repo's main page, or
   `github.com/<you>/<repo>/releases`) — the APK is attached there.

> **Note on `zarvimo-source.zip`:** this is one file *inside* the delivered
> `zarvimo-video-editor.zip`. Your phone's file manager can usually preview
> a zip's contents and let you "share" or "extract just this one file"
> without extracting everything — do that once to pull out
> `zarvimo-source.zip` by itself, then upload only that in step 3. **The
> uploaded file's name doesn't actually matter** — the workflow's extraction
> step looks for *any* `.zip` file sitting at the repo root and extracts
> whichever one it finds, so a rename GitHub or your file manager applies
> (e.g. `zarvimo-source (1).zip`) still works. If your file manager can't
> pick a single file out of a zip at all, use Option B instead.

### Option B — normal repo, extract once

1. Extract `zarvimo-video-editor.zip` fully (on a computer, or any phone zip
   app that extracts everything at once).
2. Upload the extracted contents — `app/`, `gradle/`, `.github/`,
   `settings.gradle.kts`, `gradlew`, etc. — to a new GitHub repo's root
   (drag-and-drop on desktop, or `git add . && git commit && git push`).
   There is no `zarvimo-source.zip` to deal with in this case; the workflow's
   extraction step quietly skips itself when it doesn't find one.
3. Same as Option A from step 4 onward: run the workflow, then check
   **Releases** for the APK.

### The workflow, in full

This is exactly what's committed at `.github/workflows/android-build.yml` —
shown here so you can copy it directly if you're using Option A:

```yaml
name: Android Build

on:
  workflow_dispatch:
  push:
    branches:
      - main

permissions:
  contents: write

jobs:
  build:
    name: Build and release debug APK
    runs-on: ubuntu-latest

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Extract project source (if zipped)
        run: |
          echo "Repository root contents:"
          ls -la

          if [ ! -f settings.gradle.kts ]; then
            ZIP_FILE=$(find . -maxdepth 1 -iname "*.zip" | head -n 1)
            if [ -n "$ZIP_FILE" ]; then
              echo "Found zip at repo root: $ZIP_FILE — extracting it."
              unzip -o "$ZIP_FILE" -d .
            else
              echo "No zip file found at repo root, and settings.gradle.kts is also missing."
            fi
          fi

          test -f settings.gradle.kts || {
            echo "::error::settings.gradle.kts still not found after extraction. Files currently at repo root:"
            ls -la
            exit 1
          }
          chmod +x gradlew

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"
          cache: gradle

      - name: Accept Android SDK licenses and install required packages
        run: |
          SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
          if [ ! -x "$SDKMANAGER" ]; then
            SDKMANAGER="sdkmanager"
          fi
          yes | "$SDKMANAGER" --licenses || true
          "$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

      - name: Run unit tests
        run: ./gradlew testDebugUnitTest --stacktrace

      - name: Show failing test details
        if: failure()
        run: |
          echo "========== JUnit test reports =========="
          REPORTS=$(find app/build/test-results -name "*.xml" 2>/dev/null)
          if [ -z "$REPORTS" ]; then
            echo "No JUnit XML reports were found — the tests likely never ran because of a compile error. Re-check the 'Run unit tests' step's own log above this one for a Kotlin compiler error."
          else
            for f in $REPORTS; do
              echo "---- $f ----"
              cat "$f"
              echo ""
            done
          fi

      - name: Build debug APK
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload test results
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: unit-test-results
          path: app/build/reports/tests/testDebugUnitTest/
          if-no-files-found: ignore

      - name: Upload debug APK as workflow artifact
        uses: actions/upload-artifact@v4
        with:
          name: zarvimo-debug-apk
          path: app/build/outputs/apk/debug/*.apk
          if-no-files-found: error

      - name: Publish APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ github.run_number }}
          name: Zarvimo Debug Build #${{ github.run_number }}
          prerelease: true
          files: app/build/outputs/apk/debug/*.apk
```

Every workflow run creates its own Release (tagged `build-1`, `build-2`, …),
so re-running never overwrites an earlier APK. The APK also stays available
as a 90-day workflow artifact either way, as a backup.

Locally (if you have a computer with a JDK 17 + Android SDK): extract the
zip and run `./gradlew testDebugUnitTest assembleDebug`.

### Honesty about what was verified in this environment

This project was built in a sandboxed environment with **no access to Maven
Central, Google's Maven repository, or the Gradle plugin portal** — only a
small package-manager allowlist and GitHub. That means a full
`./gradlew assembleDebug` (which needs to download the Android Gradle Plugin,
Compose, and Media3 artifacts) could not be run or verified end-to-end here.
What *was* verified directly, with the real project files, before packaging:

- **Every Kotlin source file compiles cleanly** against the real Kotlin 2.0.21
  compiler (extracted from a local Gradle install) and the real
  `kotlinx-serialization`/`kotlinx-coroutines` jars used by this project —
  checked file-by-file and in combination for the data, undo/redo,
  repository, and clip-editing logic.
- **The full unit test suite (21 tests) passes** against the real JUnit
  4.13.2 runner and the real source files in `app/src/test/`.
- **Core editing logic was exercised with real assertions**, not just
  compiled: `ProjectRepository` save/load/list/delete round-tripping real
  JSON through a real filesystem; the clip-split algorithm (mid-clip split,
  cross-clip split, edge-margin no-op, total duration preserved); clip
  delete/reorder/trim including re-indexing and bounds-clamping.
- **The Gradle Kotlin DSL files are syntactically valid**: `gradle --offline
  help` against the real project parses `settings.gradle.kts` and
  `build.gradle.kts` successfully and gets as far as plugin *resolution*,
  which is exactly where it's expected to fail without network access (it
  correctly reports it cannot reach Google's Maven repo for the Android
  Gradle Plugin — there is no other error).
- **The GitHub Actions workflow YAML is valid** (parsed with PyYAML) and its
  `on:` triggers are exactly `workflow_dispatch` and `push` to `main`, as
  required.
- **`gradlew`/`gradlew.bat` and `gradle-wrapper.jar` are the genuine Gradle
  8.14.3 wrapper artifacts**, extracted directly from a local Gradle 8.14.3
  installation (not hand-written), so there is no risk of an invalid or
  corrupted wrapper jar.
- Every `R.string.*`, `R.drawable.*`, and intra-project import used in the
  Kotlin source was cross-checked against the actual resource/source files
  and all resolve.

What was **not** verified here, and should be checked on first CI run or
local build with full network access: full dependency resolution and the
actual `assembleDebug`/instrumented build output, since the Android Gradle
Plugin, Jetpack Compose compiler, and Media3 artifacts could not be
downloaded in this sandbox. The provided GitHub Actions workflow is the
intended way to get that full, real build — please check its first run.

## Phase 2 roadmap (architecture already allows for)

- Frame-accurate overlay timing in export (see limitation above).
- Multiple overlapping text/sticker layers, image overlays, transitions.
- Project thumbnails generated from the first frame.
- Waveform display on the timeline.
- Cloud backup / project sharing.
